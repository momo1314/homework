<?php
return array(
    'dsn' => 'mysql:host=localhost;dbname=test',
    'user' => 'root',
    'password' => 'root'
);